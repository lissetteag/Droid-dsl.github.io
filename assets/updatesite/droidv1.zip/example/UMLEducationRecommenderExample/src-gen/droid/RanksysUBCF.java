package droid;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.ArrayList;

import filesExt.ranksys.cf.UBCF;
import filesExt.ranksys.rec.RecommenderIF;

public class RanksysUBCF {
public static void execute(String[] codeCase) throws ClassNotFoundException, IllegalAccessException, InstantiationException,
			InvocationTargetException, NoSuchMethodException, IOException {
String project = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample";	
String[] datasets = new String[] {project}; 
String repository = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/instances";
						 	      
String nFolds = "10";
	int maxRec = 5;
	int[] cutoffs = {5,10};
	String relevanceThreholds = "0.5";
	String errorStrategy = "NOT_CONSIDER_NAN";
	
	List<String> metricList = new ArrayList<String>();
	metricList.add("Precision");metricList.add("Recall");metricList.add("F1");metricList.add("NDCG");metricList.add("ISC");metricList.add("USC");metricList.add("MAP");

String metrics = null;
List<String> metricsUSC_ISC = new ArrayList<String>();
int count = metricList.size();
for (String m : metricList) {
if (m.equals("Precision") || m.equals("Recall") || m.equals("NDCG") || m.equals("MAP")) {
if (metrics == null) {
if (count > 1) {
metrics = "net.recommenders.rival.evaluation.metric.ranking." + m + "," ;
}
count = count - 1;
} else {
if (count > 1) {
metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m + ",");
} else {
metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m);
}
}
count = count - 1;
}
}
for (String m : metricList) {
if (m.equals("ISC")) {
metricsUSC_ISC.add("ItemSpaceCoverage");
}
if (m.equals("USC")) {
metricsUSC_ISC.add("targetSpaceCoverage");
}
}

	RecommenderIF[] recs = new RecommenderIF[]{	
	new UBCF(5),	new UBCF(10),	new UBCF(15),};					
					
															Ranksys.recommendation(recs, repository, datasets, codeCase[0], nFolds, maxRec);
															try {
																Ranksys.evaluation(datasets, nFolds, relevanceThreholds, errorStrategy, cutoffs, metrics, metricsUSC_ISC);
																} catch (ClassNotFoundException | IllegalAccessException | InstantiationException | InvocationTargetException
																							| NoSuchMethodException | IOException e) {
															e.printStackTrace();}}}
