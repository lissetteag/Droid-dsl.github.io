package droid;
	
	import java.io.BufferedWriter;
	import java.io.File;
	import java.util.Iterator;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.HashSet;
	import java.util.List;
	import java.util.Map;
	import java.util.Map.Entry;
	import java.util.Set;
	import java.util.TreeSet;
	
	import org.eclipse.emf.common.util.TreeIterator;
	import org.eclipse.emf.ecore.EObject;
	import org.eclipse.emf.ecore.resource.Resource;
	
	import filesExt.ranksys.ini.Element;
	import filesExt.ranksys.ini.ReferenceElement;
	import filesExt.ranksys.ini.Clean;
	import filesExt.ranksys.ini.ItemDistribution;
	import filesExt.ranksys.ini.LevenshteinDistance;
	import filesExt.ranksys.ini.LexicographicChanges;
	import filesExt.ranksys.ini.Printer;
	import filesExt.ranksys.ini.Sorter;
	
	import org.eclipse.uml2.uml.Property;
	import org.eclipse.uml2.uml.Class;
	import org.eclipse.uml2.uml.Operation;
	import org.eclipse.uml2.uml.Class;
	
		public class RanksysReadFile {
		Element target;
		List<ReferenceElement> items;
		String URI;
		public static List<EObject> targetObject = new ArrayList<EObject>();
		public static HashMap<Set<Object>, Integer> targetData = new HashMap<Set<Object>, Integer>();
		public static HashMap<String, String> targetDataEval = new HashMap<String, String>();
		public static HashMap<Set<Object>, Integer> targetDataSer = new HashMap<Set<Object>, Integer>();
		public static HashMap<Set<Object>, Integer> targetDataSerEval = new HashMap<Set<Object>, Integer>();				
		static HashMap<Set<Object>, String> itemData = new HashMap<Set<Object>, String>();
		static HashMap<Set<Object>, Integer> itemDataSer = new HashMap<Set<Object>, Integer>();
		static HashSet<String> itemDataOriginalUnique = new HashSet<String>();
		static HashSet<String> targetDataOriginalUnique = new HashSet<String>();
		static HashMap<Integer, Set<Object>> itemDataClean = new HashMap<Integer, Set<Object>>();
		static HashMap<Integer, Set<Object>> itemDataUnified = new HashMap<Integer, Set<Object>>();
		static HashMap<Integer, Set<Object>> itemDataSetClean = new HashMap<Integer, Set<Object>>();
		static HashMap<Integer, String> itemIndentifier = new HashMap<Integer, String>();
		static HashMap<Integer, Set<Object>> itemDataItemDistReduced = new HashMap<Integer, Set<Object>>();
		static HashMap<Integer, Set<Object>> itemDataItemPerTargetReduced = new HashMap<Integer, Set<Object>>();
		static HashMap<Integer, String> itemDataTypeSer = new HashMap<Integer, String>();
		static HashMap<Set<Object>, String> itemFeatureData = new HashMap<Set<Object>, String>();
		static HashMap<Set<Object>, Integer> itemFeatureDataSer = new HashMap<Set<Object>, Integer>();
		static HashMap<Set<Object>, Integer> itemFeatureDataClean = new HashMap<Set<Object>, Integer>();
		static HashMap<Set<Object>, Integer> itemFeatureDataUnified = new HashMap<Set<Object>, Integer>();
		public static String keyValue;
		FileWriter writer;	
		String outputFilesFolder = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles";
		static int minElements = 0;
		static int maxElements = 0;
		static int avgElements = 0;
		static int elementAll = 0;
		static int modelsAll = 0;
		static int modelsLoaded = 0;
		static int modelsWellFormed = 0;
		static int targetItemPairCount =0;
		static int targetItemPairCountOriginal =0;
		static double itemsPerTargetAll = 0;
		static double itemsPerTargetFinal = 0;
	
			public RanksysReadFile(Element target, List<ReferenceElement> items, String URI) {
				this.target = target;
				this.items = items;
				this.URI = URI;
			}
	
			int internalElements = 0;
			int target_Class_count = 0;
			int ItemCount = 0;
			int item_ownedAttribute_count = 0;
			int item_ownedOperation_count = 0;
	
			public void readFiles(Resource resource, File file) throws IOException {
			modelsWellFormed = modelsWellFormed + 1;
		
		//Target
		List<Class> target = new ArrayList<>();
		resource.getAllContents().forEachRemaining(e -> {
		if (e instanceof Class) {
		target.add((Class) e);
			}
		});
		target_Class_count = target_Class_count + target.size();
		
		
		//Items(item as SimpleFeature).feature.EType.name
		List<Property> ownedAttribute = new ArrayList<>();
			resource.getAllContents().forEachRemaining(e -> {
				if (e instanceof Class) {
					@SuppressWarnings("unchecked")
				List<Property> sc = (List<Property>) e.eGet(e.eClass().getEStructuralFeature("ownedAttribute"));
					for (Property c : sc) {
						ownedAttribute.add((Property) c);
					}
				}
				});
		
					item_ownedAttribute_count = item_ownedAttribute_count + ownedAttribute.size();	
		List<Operation> ownedOperation = new ArrayList<>();
			resource.getAllContents().forEachRemaining(e -> {
				if (e instanceof Class) {
					@SuppressWarnings("unchecked")
				List<Operation> sc = (List<Operation>) e.eGet(e.eClass().getEStructuralFeature("ownedOperation"));
					for (Operation c : sc) {
						ownedOperation.add((Operation) c);
					}
				}
				});
		
					item_ownedOperation_count = item_ownedOperation_count + ownedOperation.size();	
	
	
	ItemCount =
	+ item_ownedAttribute_count
	+ item_ownedOperation_count
	;	
	
			internalElements = 0;
			resource.getAllContents().forEachRemaining(e -> {
	elementAll = elementAll + 1;
	internalElements = internalElements + 1;
		});
	
			if (minElements == 0) {
	minElements = internalElements;
		} else if (internalElements < minElements) {
			minElements = internalElements;
		}
	
			if (maxElements == 0) {
	maxElements = internalElements;
		} else if (internalElements > maxElements) {
			maxElements = internalElements;
		}					
	
		TreeIterator<EObject> tree = resource.getAllContents();
		while (tree.hasNext()) {
			try {
				EObject obj = tree.next();
				readAttributeValues(obj, file);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
	
	public void openFile(File folder, String data) throws IOException {
		writer = new FileWriter(folder +"/"+ data + "_statistics.txt");
	}

	public void closeFile() throws IOException {
	writer.close();
	}		
	
	public void preProcessing(String path, int ld, int ratItem, int ratTarget, boolean scr) throws IOException {
		String text = Integer.toString(ld)+Integer.toString(ratItem)+Integer.toString(ratTarget)+Boolean.toString(scr);
			
		avgElements = elementAll/modelsWellFormed;
		writer.write("Special characters removal, " + scr + ", 0 ,c" + "\n");
		writer.write("Levenshtein distance merging number, " + ld + ", 0 ,c" + "\n");
		writer.write("Minimun ratings per item, " + ratItem + ", 0 ,c" + "\n");
		writer.write("Minimun ratings per target, " + ratTarget + ", 0 ,c" + "\n");
			
		writer.write("# of models, "+ modelsAll + ", 0 , a" + "\n");
		writer.write("# of loading models, " + modelsLoaded + ", 0 , a"  + "\n");
		writer.write("# of well-formed models, " + modelsWellFormed +  ", 0 , a" + "\n");
		writer.write("Avg size, " + avgElements + ", 0 , a" + "\n");
		writer.write("Min size, " + minElements + ", 0 , a" + "\n");
		writer.write("Max size, "  + maxElements + ", 0 , a" + "\n");
							
		Integer i = 0; // for the id's of user HashMap
		Integer j = 0; // for the id's of item HashMap
		Integer k = 0; // for the id's of item_features HashMap
		
		targetData = Sorter.sort(targetData);
		for (Entry<Set<Object>, Integer> entry : targetData.entrySet()) {
			Set<Object> key = entry.getKey();
			targetDataSer.put(key, i);
			targetDataOriginalUnique.add(key.toString());

			for (Entry<String, String> entry2 : targetDataEval.entrySet()) {
				if (key.toString().equals(entry2.getKey())) {
					Set<Object> serialization = new TreeSet<Object>();
					String valuePair = key + ":" + entry2.getValue();
					serialization.add(valuePair.trim());
					targetDataSerEval.put(serialization, i);
				}
			}
			i++;
		}

		

		itemData = Sorter.sort4(itemData);
		for (Entry<Set<Object>, String> entry : itemData.entrySet()) {
			Set<Object> key = entry.getKey();
			
			String type =  entry.getValue(); 
			
			String ix = "";
			Iterator<Object> it = key.iterator();
			ix += type+ ":";
			while(it.hasNext()){
			ix += (String) it.next()+ ":";
			}
			ix += URI;
			
			itemDataSer.put(key, j);
			itemDataTypeSer.put(j, entry.getValue());
			itemIndentifier.put(j, ix);
			j++;
			itemDataOriginalUnique.add(key.toString());
		}
		
			itemFeatureData = Sorter.sort0(itemFeatureData);
				for (Entry<Set<Object>, String> entry : itemFeatureData.entrySet()) {
					Set<Object> keySet = entry.getKey();
					itemFeatureDataSer.put(keySet, k);
					k++;
				}
		
				String pathCoded = path + "//coded//ranksys//" + text;
				File theDir = new File(pathCoded);
				if (!theDir.exists()){
					theDir.mkdirs();
					}
	
				Printer.print(targetDataSer, "valuesTarget", pathCoded);
				Printer.print(targetDataSerEval, "valuesTargetEval", pathCoded);
				Printer.print(itemDataSer, "valuesItems", pathCoded);
				Printer.print(itemDataTypeSer, "valuesItemsTypes", pathCoded);
				Printer.print(itemFeatureDataSer, "valuesItemsFeatures", pathCoded);
				Printer.print(itemIndentifier, "valuesItemsIdentifiers", pathCoded);
				
				writer.write("# of targets, " + target_Class_count + "," + targetDataOriginalUnique.size() + ",b" + "\n");
				writer.write("# of items, " + ItemCount + "," + itemDataOriginalUnique.size() + ",b" + "\n");		
	
			if (scr == true) {
				System.out.println("  Special characters removal...");
				itemDataClean = LexicographicChanges.specialCharactersRemoval(itemDataSer, writer);
				Printer.print(itemDataClean, "p1-dataCleanedItemValues", pathCoded);
				
				System.out.println("  Levenshtein distance merging " + ld + "...");
				itemDataUnified = LevenshteinDistance.merging(itemDataClean, ld, writer, keyValue);
				Printer.print(itemDataUnified, "p2-LDItemValues", pathCoded);
				
				System.out.println("  Cleaning dataset...");
				itemDataSetClean = Clean.cleanDataSet(itemDataUnified, writer, keyValue);
				Printer.print(itemDataSetClean, "p3-dataSetCleanedItemValues", pathCoded);
				
				System.out.println("  Updating to minimun ratings per item " + ratItem + "...");
				itemDataItemDistReduced = ItemDistribution.minRatingsPerItem(itemDataSetClean,ratItem,pathCoded,writer,keyValue);
				Printer.print(itemDataItemDistReduced, "p4-valuesItemDistReduced", pathCoded);
			} else {
				System.out.println("  Levenshtein distance merging " + ld + "...");
				itemDataUnified = LevenshteinDistance.unifyWordsNoCleaned(itemDataSer, ld, writer, keyValue);
				Printer.print(itemDataUnified, "p2-LDItemValues", pathCoded);
	
				System.out.println("  Cleaning dataset...");
				itemDataSetClean = Clean.cleanDataSet(itemDataUnified, writer, keyValue);
				Printer.print(itemDataSetClean, "p3-dataSetCleanedItemValues", pathCoded);
	
				System.out.println("  Updating to minimun ratings per item " + ratItem + "...");
				itemDataItemDistReduced = ItemDistribution.minRatingsPerItem(itemDataSetClean, ratItem, pathCoded, writer, keyValue);
				Printer.print(itemDataItemDistReduced, "p4-valuesItemDistReduced", pathCoded);
	}
	}
	
	public void readAttributeValues(EObject obj, File file) throws IOException {
			HashMap<String, String> mapUser = new HashMap<String, String>();
			HashMap<String, String> mapItems = new HashMap<String, String>();
			HashMap<String, String> mapFeatures = new HashMap<String, String>();
			Set<Object> serialization = new TreeSet<Object>();
			
			if (obj.eClass().equals(target.getClass_e())) {
				targetObject.add(obj);
				if (!target.serialize(obj).isEmpty()) {
					mapUser = target.serialize(obj);
					for (Map.Entry<String, String> entry : mapUser.entrySet()) {
						String valuePair = entry.getKey().trim() + ":" + entry.getValue().trim();
						serialization.add(valuePair.trim());
						targetData.put(serialization, 0);
						targetDataEval.put(serialization.toString(), file.getName());
					}
				}
				for (ReferenceElement item : items) {
					List<EObject> refList = item.getReferenceObject(obj);
					for (Object refListElement : refList) {
						mapItems = item.serialize((EObject) refListElement);
						String type = item.serialize2((EObject) refListElement);
						for (Map.Entry<String, String> entry : mapItems.entrySet()) {
							Set<Object> itemSerialization = new TreeSet<Object>();
							String valuePair = entry.getKey().trim() + ":" + entry.getValue().trim();
							keyValue = entry.getKey();
							itemSerialization.add(valuePair.trim());
							itemData.put(itemSerialization, type.trim());
						}
						mapFeatures = item.serializeFeature((EObject) refListElement);
						for (Map.Entry<String, String> entry : mapFeatures.entrySet()) {
							Set<Object> value = new TreeSet<Object>();
							value.add(entry.getKey().trim() + ":" + entry.getValue().trim());
							itemFeatureData.put(value, entry.getKey().trim());
						}
					}
				}
			}
	}
	
	public void generateMatrix(String path, int ld, int ratItem, int ratTarget, boolean scr) throws IOException {
		itemsPerTargetAll = (double)(itemDataSer.size()) / targetData.size();
		itemsPerTargetFinal = (double)(itemDataItemDistReduced.size()) / targetData.size();
		writer.write("Avg items per target, " + String.format("%.2f", itemsPerTargetAll) + "," + String.format("%.2f", itemsPerTargetFinal) + " , b" + "\n");								
		
		HashMap<Integer, Integer> listTargetCount = new HashMap<Integer, Integer>();
		HashMap<Integer, Integer> finalListTargets = new HashMap<Integer, Integer>();
		List<Integer> listItemsWithTargets = new ArrayList<>();
		String text=Integer.toString(ld)+Integer.toString(ratItem)+Integer.toString(ratTarget)+Boolean.toString(scr);
	
			double[][] matrix_target_item = createMatrix(targetDataSer.size(), itemDataItemDistReduced.size());
			double[][] matrix_item_feature = createMatrix(itemDataItemDistReduced.size(), itemFeatureDataSer.size());
			double[][] matrix_target_itemOriginal = createMatrix(targetDataSer.size(), itemDataSer.size());
			
			HashMap<Integer, Integer> newMap = new HashMap<Integer, Integer>();
			for (Entry<Integer, Set<Object>> entry : itemDataItemDistReduced.entrySet()) {
			String[] set = entry.getValue().toString().split(">");
			String id = set[1].replace("]", "");
			newMap.put(Integer.parseInt(id), entry.getKey());
			}
	for (EObject obj_u : targetObject) {
		for (ReferenceElement item : items) {
			Set<Object> serializacion_target = target.serialize2(obj_u);
			List<EObject> refList = item.getReferenceObject(obj_u);
			for (EObject obj_i : refList) {
				Set<Object> serializacion_item = new TreeSet<Object>();
				HashMap<String, String> mapItem = item.serialize(obj_i);
				for (Map.Entry<String, String> entry : mapItem.entrySet()) {
					String valuePair = entry.getKey() + ":" + entry.getValue();
					serializacion_item.add(valuePair);
				}
				int target_index = 0;
				if (!serializacion_target.isEmpty()) {
					// get the user index from HashMap
					try {
						target_index = targetDataSer.get(serializacion_target);
					} catch (Exception e) {
						/* ignore */
					}
				}
				int item_index = 0;
				if (!serializacion_item.isEmpty()) {
					// get the item index from HashMap
					try {
						int temp_intex = itemDataSer.get(serializacion_item);
						item_index = newMap.get(temp_intex);
						matrix_target_item[target_index][item_index] = 1;
						} catch (Exception e) {
					}
				}
				
				int item_indexOrg = 0;
				if (!serializacion_item.isEmpty()) {
					// get the item index from HashMap
					try {
						item_indexOrg = itemDataSer.get(serializacion_item);
						matrix_target_itemOriginal[target_index][item_indexOrg] = 1;
	} catch (Exception e) {	}}
	
	HashMap<String, String> map = item.serializeFeature(obj_i);
	Set<Object> serializacion_item_feature = new TreeSet<Object>();
	for (Map.Entry<String, String> entry : map.entrySet()) {
		String valuePair = entry.getKey() + ":" + entry.getValue();
		serializacion_item_feature.add(valuePair);
	}
	int item_feature_index = 0;
	if (!serializacion_item_feature.isEmpty()) {
		// get the item feature index from HashMap
		try {
			item_feature_index = itemFeatureDataSer.get(serializacion_item_feature);
			matrix_item_feature[item_index][item_feature_index] = 1;
		} catch (Exception e) {
			/* ignore */}}}}}
	
	PrintWriter save_matrix_user_item = null;
	try {
		save_matrix_user_item = new PrintWriter(
				new BufferedWriter(new FileWriter(outputFilesFolder + "/dataPostProcessing/ranksys/" + text + "_dataset_ratings" + ".dat")));
		save_matrix_user_item.println("target" + "\t" + "item" + "\t" + "rating");
		for (int i = 0; i < matrix_target_item.length; i++) {
			for (int j = 0; j < matrix_target_item[i].length; j++) {
				if (matrix_target_item[i][j] == 1) { // saving only the ones with ratings (1's)
					if (listTargetCount.get(i) == null) {
						listTargetCount.put(i, 1);
					} else {
						listTargetCount.put(i, listTargetCount.get(i) + 1);
					}
				}
			}
		}
		
		for (int i = 0; i < matrix_target_itemOriginal.length; i++) {
			for (int j = 0; j < matrix_target_itemOriginal[i].length; j++) {
				if (matrix_target_itemOriginal[i][j] == 1) { // saving only the ones with ratings (1's)
					targetItemPairCountOriginal = targetItemPairCountOriginal + 1;
				}
			}
		}
	for (int i = 0; i < matrix_target_item.length; i++) {
		for (int j = 0; j < matrix_target_item[i].length; j++) {
			if (matrix_target_item[i][j] == 1) { // saving only the ones with ratings (1's)
				if (ratTarget > 0) {
					if (listTargetCount.get(i) >= ratTarget) {
						finalListTargets.put(i, 1);
						targetItemPairCount = targetItemPairCount + 1;
						save_matrix_user_item.println(i + "\t" + j + "\t" + matrix_target_item[i][j]);
						if (!listItemsWithTargets.contains(j)) {
							listItemsWithTargets.add(j);
						}
					}
				} else {
					finalListTargets.put(i, 1);
					save_matrix_user_item.println(i + "\t" + j + "\t" + matrix_target_item[i][j]);
					if (!listItemsWithTargets.contains(j)) {
						listItemsWithTargets.add(j);
					}
				}
	}
	}
	}
	
	
	
	
		float a = finalListTargets.size();
		float b = targetDataOriginalUnique.size();
		
		if (listItemsWithTargets.size() > 0) {
			float total = a / b * 100;
			writer.write("% of target, " + Math.round(total) + "," + 0 + ",e" + "\n");
		} else {
			writer.write("% of target, 0 , 0 , e" + "\n");
		}
		
		float c = listItemsWithTargets.size();
		float d = itemDataOriginalUnique.size();
		if (listItemsWithTargets.size() > 0) {
			float total = c / d * 100;
			writer.write("% of items, " + Math.round(total) + "," + 0 + ",e"  + "\n");
		} else {
			writer.write("% of items, 0 , 0 , e" + "\n");
		}
	
		} catch (IOException ex) {
		// Report
		} finally {
			try {
				save_matrix_user_item.close();
			} catch (Exception ex) {
				/* ignore */}
		}
			
	
	PrintWriter save_matrix_item_feature = null;
					try {
						save_matrix_item_feature = new PrintWriter(
								new BufferedWriter(new FileWriter(outputFilesFolder + "/dataPostProcessing/ranksys/" + text + "_dataset_item_features" + ".dat")));
						save_matrix_item_feature.println("# item" + "\t" + "feature" + "\t" + "rating");
						for (int i = 0; i < matrix_item_feature.length; i++) {
							for (int j = 0; j < matrix_item_feature[i].length; j++) {
								if (matrix_item_feature[i][j] == 1) { // saving only the ones with ratings (1's)
									if (listItemsWithTargets.contains(i)) {
										save_matrix_item_feature.println(i + "\t" + j + "\t" + matrix_item_feature[i][j]);
									}
								}
							}
						}
					} catch (IOException ex1) {
						// Report
					} finally {
						try {
							save_matrix_item_feature.close();
							} catch (Exception ex) {
							/* ignore */}
						}
					
	float allPosibleRatings = targetDataSer.size() * itemDataSer.size();
	float actualRatingDivAllPosibles = targetItemPairCountOriginal/ allPosibleRatings;
	float a = 1 - actualRatingDivAllPosibles;
	float sparcityInitial = a * 100;
	
	float allPosibleRatings2 = targetDataSer.size() * itemDataItemDistReduced.size();
	float actualRatingDivAllPosibles2 = targetItemPairCount/ allPosibleRatings2;
	float a2 = 1 - actualRatingDivAllPosibles2;
	float sparcityFinal = a2* 100; 
	
	writer.write("sparcity before, " +  sparcityInitial + "," + 0 + ", b21" + "\n");	
	writer.write("sparcity after, " +  sparcityFinal + "," +0  + ", b22" + "\n");	
	}
	
	public static double[][] createMatrix(int x, int y) {
		double[][] matrix = new double[x][y];
		for (int i = 0; i < x; i++) {
			for (int j = 0; j < y; j++) {
				matrix[i][j] = 0;
			}
		}
		return matrix;
	}
		
	public static void cleanInitialMaps() {
		targetObject.clear();
		targetData.clear();
		targetDataEval.clear();
		itemData.clear();
		itemFeatureData.clear();
	}

	public static void cleanSecundaryMaps() {
	targetDataSer.clear();
	targetDataSerEval.clear();
	targetDataOriginalUnique.clear();
	itemDataSer.clear();
	itemDataTypeSer.clear();
	itemDataOriginalUnique.clear();
	itemFeatureDataSer.clear();
	targetItemPairCount = 0;
	targetItemPairCountOriginal = 0;
	itemsPerTargetAll = 0;
	itemsPerTargetFinal = 0;
	}
	
	}
