package droid;

public class Helper {
	public void setCodeCase(String codeC) throws Exception {
		String[] codeCase =  new String[]{codeC};
		EngineConfiguration.main(codeCase);
			RanksysIBCF.execute(codeCase);
			RanksysUBCF.execute(codeCase);
			RanksysItemPop.execute(codeCase);
			RanksysCosineCB.execute(codeCase);
			RanksysCBUB.execute(codeCase);
			RanksysCBIB.execute(codeCase);
			MemoRecCACF.execute(codeCase);
			RanksysEvaluationFinal.execute();
			}
			}
