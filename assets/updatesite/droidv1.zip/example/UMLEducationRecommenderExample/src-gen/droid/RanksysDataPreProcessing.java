package droid;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;	
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;		
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.common.util.WrappedException;
import org.eclipse.emf.ecore.xmi.UnresolvedReferenceException;
import org.eclipse.uml2.uml.UMLPackage;
import org.eclipse.uml2.uml.resource.UMLResource;
import org.eclipse.emf.ecore.impl.EReferenceImpl;

import filesExt.ranksys.ini.Element;
import filesExt.ranksys.ini.ReferenceElement;    

public class RanksysDataPreProcessing {
	static List<Element> elements = new ArrayList<>();
	public static boolean[] specialCharRemoval ={true};
	public static int[] editDistanceMerging ={2,3,4};
	public static int[] minRatingsPerItem = {1,2};
	public static int[] minRatingsPerTarget = {1,2};
	public static void main(String[] arg) throws Exception, UnresolvedReferenceException {
		String repository = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/instances";
		String droidRESTFolder = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/droidREST";
		String statisticsFolder = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/statistics";
		File configFilesFolder = new File("C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/configFiles");
		File outputStatistics = new File(statisticsFolder);
		File dataPostProFolderRanksys = new File("C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/dataPostProcessing/ranksys");
		
		FileUtils.cleanDirectory(outputStatistics);
		FileUtils.cleanDirectory(dataPostProFolderRanksys); 
		FileUtils.cleanDirectory(new File("C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/droidREST/coded/ranksys"));
		FileUtils.cleanDirectory(new File("C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/droidREST/coded/memorec"));
		FileUtils.cleanDirectory(new File("C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/droidREST/general"));
		FileUtils.cleanDirectory(new File("C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles/configFiles"));
		Map<String, List<String>> targetIdentifierMap = new HashMap<>();
		Map<String, List<String>> ItemsIdentifierMap = new HashMap<>();		
						
		Arrays.stream(configFilesFolder.listFiles()).forEach(file -> {
			try {
				if (file.toString().endsWith(".zip")) {
					file.delete();
					}
				} catch (Exception ex) {
			}
		});

	ResourceSet resourceSet = new ResourceSetImpl();
	resourceSet.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE); 
	resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION,
	UMLResource.Factory.INSTANCE);
	Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION,
	UMLResource.Factory.INSTANCE);
	EPackage.Registry.INSTANCE.put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);
	UMLPackage simpleUML = (UMLPackage) UMLPackage.eINSTANCE;
	String URI =simpleUML.getNsURI();
	File folder = new File(repository);
	List<String> targetAttributesPk_Class = new ArrayList<>();
	EClass target_Class = (EClass) simpleUML.getEClassifier("Class");
	targetAttributesPk_Class.add("name"); 
					targetIdentifierMap.put("Class", targetAttributesPk_Class);
					Element elem_Class = getElement(target_Class, targetAttributesPk_Class, new ArrayList<>());
					elements.add(elem_Class);
	
	EClass eclass0 = (EClass) simpleUML.getEClassifier("Type");
	List<String> pks0 = new ArrayList<>();
	pks0.add("name");
	Element elem0 = getElement(eclass0, pks0, new ArrayList<>());
	elements.add(elem0);
	
	List<String> item1AttributesPk= new ArrayList<>();
																								EClass item_1 = (EClass) simpleUML.getEClassifier("Property");
																								item1AttributesPk.add("name");
																								List<String> item1AttributesFeatures= new ArrayList<>();
																								item1AttributesFeatures.add("name");
	Element elem_1 = getElement(item_1, targetAttributesPk_Class, new ArrayList<>());
	elements.add(elem_1);
	List<String> item2AttributesPk= new ArrayList<>();
																								EClass item_2 = (EClass) simpleUML.getEClassifier("Operation");
																								item2AttributesPk.add("name");
																								List<String> item2AttributesFeatures= new ArrayList<>();
																								item2AttributesFeatures.add("name");
	Element elem_2 = getElement(item_2, targetAttributesPk_Class, new ArrayList<>());
	elements.add(elem_2);
	
	Element target = getElement("Class");			            
	List<ReferenceElement> items = new ArrayList<>();
	ReferenceElement item1 = getReferenceElement(target.getClass_e(), "ownedAttribute");    
	items.add(item1);
	ItemsIdentifierMap.put("ownedAttribute", item1AttributesPk);
	ReferenceElement item2 = getReferenceElement(target.getClass_e(), "ownedOperation");    
	items.add(item2);
	ItemsIdentifierMap.put("ownedOperation", item2AttributesPk);
	RanksysReadFile read = new RanksysReadFile(target, items, URI);	
	System.out.println("- Started -");
	if (folder.exists() && folder.isDirectory()) {
	System.out.println("Reading files...");
	RanksysReadFile.cleanInitialMaps();
	for (File subFile : folder.listFiles()) {
	if (subFile.getName().endsWith(".uml")) { 
	RanksysReadFile.modelsAll = RanksysReadFile.modelsAll + 1;
	try {
	Resource resource = resourceSet.getResource(createURI(subFile.getPath()), true);
	read.readFiles(resource, subFile);
	RanksysReadFile.modelsLoaded = RanksysReadFile.modelsLoaded + 1;
	} catch (WrappedException e) {
	System.out.println("WrappedException: " + e);
	} catch (NullPointerException e) {
	System.out.println("NullPointerException: " + e);
	} catch (Exception e) {
	System.out.println("Exception: " + e);}}}  
				
	System.out.println("Pre-processing...");
	for (int ld : editDistanceMerging) {
		for (int ratItem : minRatingsPerItem) {
			for (int ratTarget : minRatingsPerTarget) {
				for(boolean scr: specialCharRemoval) {
					RanksysReadFile.cleanSecundaryMaps();
					String text = String.valueOf(ld) + String.valueOf(ratItem) + String.valueOf(ratTarget) + Boolean.toString(scr);
					read.openFile(outputStatistics, text);
					read.preProcessing(droidRESTFolder, ld, ratItem, ratTarget, scr);
					System.out.println("Generating matrices...");
					System.out.println("  Updating to minimun ratings per target " + ratTarget + "...");
					read.generateMatrix(droidRESTFolder, ld, ratItem, ratTarget, scr);
					read.closeFile();
					}
				}
			}
		}
	}
	
	FileWriter writer = new FileWriter(droidRESTFolder + "/general/editorTargetItems.txt");
	for (String str : targetIdentifierMap.keySet()) {
		String key = str.toString();
		String value = targetIdentifierMap.get(str).toString();
		writer.write("target/" + key + "/" + value + System.lineSeparator());
		}
	for (String str : ItemsIdentifierMap.keySet()) {
		String key = str.toString();
		String value = ItemsIdentifierMap.get(str).toString();
		writer.write("item/" + key + "/" + value + System.lineSeparator());
		}
	writer.close();						
	System.out.println("- Done -");						
	}
	public static ReferenceElement getReferenceElement(EClass targetClass, String name) {
		EReference itemReference = (EReference) targetClass.getEStructuralFeature(name);
		EClass itemClass = (EClass) itemReference.getEReferenceType();
		Element itemType = getElement(itemClass.getName());
		String type = itemClass.getName();
		ReferenceElement item = new ReferenceElement(itemReference, itemType, type);
		return item;
	}
	
	public static Element getElement(EClass eclass, List<String> pk, List<String> features) {
		Element element = new Element(eclass);
		List<EAttribute> attribute_pk = new ArrayList<>();
		List<ReferenceElement> reference_pk = new ArrayList<>();
		for (String attr : pk) {
			if (eclass.getEStructuralFeature(attr) instanceof EAttribute) {
			attribute_pk.add((EAttribute) eclass.getEStructuralFeature(attr));
			} else if (eclass.getEStructuralFeature(attr) instanceof EReferenceImpl) {
			EReference ref = (EReference) eclass.getEStructuralFeature(attr);
			ReferenceElement refElement = getReferenceElement(eclass, ref.getName());
			reference_pk.add(refElement);
			}
		}
		List<EAttribute> attributeFeature = new ArrayList<>();
		List<ReferenceElement> referenceFeature = new ArrayList<>();
		for (String attr : features) {
			if (eclass.getEStructuralFeature(attr) instanceof EAttribute) {
				attributeFeature.add((EAttribute) eclass.getEStructuralFeature(attr));
				} else if (eclass.getEStructuralFeature(attr) instanceof EReferenceImpl) {
				EReference ref = (EReference) eclass.getEStructuralFeature(attr);
				ReferenceElement refElement = getReferenceElement(eclass, ref.getName());
				referenceFeature.add(refElement);
				}
		}
		element.setAttribute_pk(attribute_pk);
		element.setAttribute_feature(attributeFeature);
		element.setReference_pk(reference_pk);
		element.setReference_feature(referenceFeature);
		return element;
	}
							
	public static Element getElement(String name) {
		for (Element elem : elements) {
			if (elem.getClass_e().getName().equals(name)) {
				return elem;
				}
			}
		return null;
	}
	public static URI createURI(String uriString){
	if (uriString.startsWith("platform:/resource/")) return URI.createPlatformResourceURI(uriString.replaceFirst("^platform:/resource/", ""), true);
	if (uriString.startsWith("platform:/plugin/"))   return URI.createPlatformPluginURI(uriString.replaceFirst("^platform:/plugin/", ""), true);
	if (uriString.startsWith("http:/"))              return URI.createURI(uriString);       
	return URI.createFileURI(new File(uriString).getAbsolutePath());
	}
	}

