		package droid;
		
		import java.io.File;
		import java.io.FileWriter;
		import java.io.IOException;
		
		public class WriterUtil {

		public static void cleanInitialMaps(String file) throws IOException {
		File file2 = new File(file);
		if (!file2.exists()) {
			file2.mkdir();
		}
	
		MemoRecReadFile.writerOriginal2 = new FileWriter(file2.toString() + "/original2.txt");
		}

		public static void openFileOriginal(String outputFolderMemorec, String fileName) throws IOException {
			File file = new File(outputFolderMemorec + "/originals/");
			if (!file.exists()) {
				file.mkdir();
			}
			MemoRecReadFile.writerOriginal = new FileWriter(file.toString() + "/" + fileName + ".txt");
	
		}

		public static void closeFileOriginal() throws IOException {
			MemoRecReadFile.writerOriginal.close();
		}
	
		public static void openFilePostPreprocesing(String outputFolderMemorec, String text) throws IOException {
			File folder = new File(outputFolderMemorec + "/" + text + "/");
			if (!folder.exists()) {
				folder.mkdir();
			}
			String pathCoded = folder.toString();
	
			MemoRecReadFile.writerPostPreprocesingMatrix = new FileWriter(pathCoded + "/dataset_ratings" + ".dat");
			MemoRecReadFile.writerPostPreprocesingMatrix.write("target" + "\t" + "item" + "\t" + "rating" + "\n");
		}
	
		public static void closeFilePostPreprocesing() throws IOException {
			MemoRecReadFile.writerPostPreprocesingMatrix.close();
		}
}
