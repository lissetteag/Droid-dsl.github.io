	package droid;
	
	import java.io.File;
	import java.io.IOException;
	import java.lang.reflect.InvocationTargetException;
	import java.util.ArrayList;
	import java.util.List;
	
	import org.apache.commons.io.FileUtils;
	
	import filesExt.memorec.ActiveDeclarationNotFoundException;
	import filesExt.memorec.DataReader;
	import filesExt.memorec.RanksysEvaluator;
	import filesExt.memorec.dto.Model;
	
	public class MemoRecCACF {
	public static void execute(String[] codeCase) throws ClassNotFoundException, IllegalAccessException, InstantiationException,
				InvocationTargetException, NoSuchMethodException, IOException, ActiveDeclarationNotFoundException {
	long startTime = System.nanoTime();
	String memorecCodeCase = codeCase[0].substring(0, 1) + codeCase[0].substring(2, codeCase[0].length());
	String project = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample" + "/";	
	String[] datasets = new String[] {project};
	
	String outputFolderUnifiedMatrix = project + "outputFiles\\droidREST\\coded\\memorec\\";
	String outputFolderIndividualMatrix = project + "outputFiles\\dataPostProcessing\\memorec\\" + memorecCodeCase + "\\";
	String outputFolderDroidDSL = project + "outputFiles\\droidDSL\\memorec\\";
	
	String evalsFolder = outputFolderDroidDSL + "evals\\";
	String recFolder = outputFolderDroidDSL + "recs\\";
	String splitFolder = outputFolderDroidDSL + "splits\\";
	String resultFolder = project + "outputFiles\\droidREST\\result\\";

	FileUtils.cleanDirectory(new File(evalsFolder));
	FileUtils.cleanDirectory(new File(recFolder));
	FileUtils.cleanDirectory(new File(splitFolder));
	FileUtils.cleanDirectory(new File(resultFolder));
	
	String splitType = "CrossValidation";
	String nFolds = "10";
	String perUser = "true"; 
	String perItem = "false"; 			
	String percentageTraining = "0.0";
	
	int[] cutoffs = {5,10};
	int maxRecommendations = 5;
	String relevanceThreholds = "0.5";
	String errorStrategy = "NOT_CONSIDER_NAN";
	List<Integer> kList = new ArrayList<>();
	kList.add(5);	kList.add(10);	kList.add(15);	
					
	List<String> metricList = new ArrayList<String>();
	metricList.add("Precision");metricList.add("Recall");metricList.add("F1");metricList.add("NDCG");metricList.add("ISC");metricList.add("USC");metricList.add("MAP");
	String metrics = null;
	List<String> metricsUSC_ISC = new ArrayList<String>();
	int count = metricList.size();
	for (String m : metricList) {
	if (m.equals("Precision") || m.equals("Recall") || m.equals("NDCG") || m.equals("MAP")) {
	if (metrics == null) {
		if (count > 1) {
		metrics = "net.recommenders.rival.evaluation.metric.ranking." + m + "," ;}
		count = count - 1;} else {if (count > 1) {
		metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m + ",");
		} else {
		metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m);}}
		count = count - 1;}}
		for (String m : metricList) {
		if (m.equals("ISC")) {
		metricsUSC_ISC.add("ItemSpaceCoverage");}
		if (m.equals("USC")) {
		metricsUSC_ISC.add("targetSpaceCoverage");}
	}
	
	Data data = new Data(splitType, nFolds, perUser, perItem, percentageTraining, memorecCodeCase);
	data.split(datasets, outputFolderUnifiedMatrix, outputFolderDroidDSL, "memorec");

	DataReader dr = new DataReader();
	List<Model> dataset = dr.readModels(outputFolderIndividualMatrix);
	MemoRecRecommendations rec = new MemoRecRecommendations(kList, dr, splitType, nFolds, maxRecommendations, memorecCodeCase);
	rec.recommendations(dataset, outputFolderIndividualMatrix, outputFolderUnifiedMatrix, outputFolderDroidDSL, splitFolder);

	RanksysEvaluator evaluator = new RanksysEvaluator(splitType, metrics, metricsUSC_ISC, nFolds,
			relevanceThreholds, errorStrategy, cutoffs, kList);
	evaluator.evaluate(outputFolderDroidDSL);
	evaluator.summaryEvaluation(outputFolderDroidDSL, resultFolder);

	long stopTime = System.nanoTime();
	long total = stopTime - startTime;
	double elapsedTimeInSecond = (double) total / 1_000_000_000;
	System.out.println("- Done - ");
	System.out.println("Time: " + elapsedTimeInSecond + " seconds.");			

	}
} 
