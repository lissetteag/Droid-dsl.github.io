	package droid;
	
	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.LinkedHashSet;
	import java.util.List;
	import java.util.Map;
	import java.util.Map.Entry;
	import java.util.Scanner;
	import java.util.Set;
	
	import filesExt.memorec.ActiveDeclarationNotFoundException;
	import filesExt.memorec.DataReader;
	import filesExt.memorec.SimilarityCalculator;
	import filesExt.memorec.dto.Model;
	import filesExt.memorec.dto.Recommender;
	
	public class MemoRecRecommendations {
		
	private List<Integer> kList;
	private DataReader dr;
	private String nFolds;
	private String splitType;
	private int maxRecommendations;
	private String codeCase;
	private static FileWriter writerRecFile;
	private static FileWriter writerRecFiles;
	public static HashMap<String, Integer> dictonaryTargets = new HashMap<String, Integer>();
	public static HashMap<String, Integer> dictonaryItems = new HashMap<String, Integer>();
	public static HashMap<String, String> dictonaryItemsString = new HashMap<String, String>();
	public static HashMap<String, String> dictonaryTargetsString = new HashMap<String, String>();
	private static HashMap<Map<Integer, Integer>, Float> recMap = new HashMap<Map<Integer, Integer>, Float>();
	
	public MemoRecRecommendations(List<Integer> kList, DataReader dr, String splitType, String nFolds,
			int maxRecommendations, String codeCase) {
		super();
		this.kList = kList;
		this.dr = dr;
		this.nFolds = nFolds;
		this.splitType = splitType;
		this.maxRecommendations = maxRecommendations;
		this.codeCase = codeCase;
	}	

	public void recommendations(List<Model> dataset, String modelContext, String outputFolderUnifiedMatrix,
				String outputFolderDroidDSL, String splitFolder)
			throws IOException, ActiveDeclarationNotFoundException {
		System.out.println("Start generating recommendations");
		List<String> targetItemTest = getTestCases(splitFolder);
		System.out.println("Start generating recommendations");
		readDictionaries(codeCase, outputFolderUnifiedMatrix);
		String folderOutput = outputFolderDroidDSL + "recs";

		if (splitType.equals("Random")) {
			nFolds = "0";
		}

		for (Integer k : kList) { 
			System.out.println("Generating recommendations for k: " + k);
			writerRecFile = new FileWriter(
					outputFolderUnifiedMatrix + "\\dataset_rec_fold" + nFolds + "__cacf" + k + ".dat");
			recMap.clear();
			File dir = new File(modelContext);
			File[] directoryListing = dir.listFiles();
			if (directoryListing != null) {
				for (File child : directoryListing) {
					String modelPath = child.toString();
					Model inputModel = dr.readModelGetContextTrainning(modelPath, splitFolder, targetItemTest);
					Set<String> targetsList = getTargetsList(new File(modelPath));
					for (String target : targetsList) {
						Recommender memoRec = new Recommender(new SimilarityCalculator(), k);
						try {
							Map<String, Float> recomendations = memoRec.recommend(target, dataset, inputModel,
									maxRecommendations);
							for (Entry<String, Float> entry : recomendations.entrySet()) {
								int elementId = getIdTarget(target);
								int recommendationId = getIdItem(entry.getKey());
								HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
								map.put(elementId, recommendationId);
								recMap.put(map, entry.getValue());
							}
						} catch (ActiveDeclarationNotFoundException e) {
							e.printStackTrace();
						}
					}
				}
				System.out.println("Start saving rec files");

				for (Entry<Map<Integer, Integer>, Float> entry : recMap.entrySet()) {
					for (Entry<Integer, Integer> entry2 : entry.getKey().entrySet()) {
						writerRecFile
								.write(entry2.getKey() + "\t" + entry2.getValue() + "\t" + entry.getValue() + "\n");
					}
				}
				writerRecFile.close();

				if (splitType.equals("CrossValidation")) {
					String file = outputFolderUnifiedMatrix + "\\dataset_rec_fold" + nFolds + "__cacf" + k + ".dat";
					splitFile(file, Integer.parseInt(nFolds), folderOutput, k);
				}
			}
		}
		System.out.println("-----------------------------");
	}

private void splitFile(String file, int nFolds, String folderOutput, Integer k) throws IOException {
	try {
		Scanner scanner = new Scanner(new File(file));
		List<String> lines = new ArrayList<String>();
		int size = 0;
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			lines.add(line);
			size = size + 1;
		}

		int init = 0;
		int fin = 0;
		for (int i = 0; i < nFolds; i++) {
			int value = size % nFolds;
			fin = init + (size / nFolds);
			if (i < value) {
				fin++;
			}
			writerRecFiles = new FileWriter(folderOutput + "\\dataset_rec_fold_" + i + "__cacf" + k + " .dat");
			for (int j = init; j < fin; j++) {
				writerRecFiles.write(lines.get(j) + "\n");
			}
			init = fin;
			writerRecFiles.close();
		}
		scanner.close();
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
}
		
private static int getIdTarget(String element) {
		int id = 0;
		if (dictonaryTargets.get(element) != null) {
			id = dictonaryTargets.get(element);
		}

		return id;
	}

	private static int getIdItem(String element) {
		int id = 0;
		if (dictonaryItems.get(element) != null) {
			id = dictonaryItems.get(element);
		}

		return id;
	}

private static void readDictionaries(String codeCase, String outputFolderUnifiedMatrix) throws IOException {
	dictonaryTargets.clear();
	File dicTargets = new File(outputFolderUnifiedMatrix + codeCase + "\\valuesTarget.dat");
	if (dicTargets.isFile()) {
		BufferedReader br = new BufferedReader(new FileReader(dicTargets.toString()));
		br.readLine(); // this will read the first line
		String line = null;
		while ((line = br.readLine()) != null) { // loop will run from 2nd
			String text = line;
			String[] parts = text.split("\t");
			String target = parts[1].replace("[name:", "").replace("]", "");
			int targetId = Integer.parseInt(parts[0]);
			dictonaryTargets.put(target, targetId);
			dictonaryTargetsString.put(parts[0], target);
		}
	}

	dictonaryItems.clear();
	File dicIems = new File(outputFolderUnifiedMatrix + codeCase + "\\valuesItems.dat");
	if (dicIems.isFile()) {
		BufferedReader br = new BufferedReader(new FileReader(dicIems.toString()));

		br.readLine(); // this will read the first line
		String line = null;
		while ((line = br.readLine()) != null) { // loop will run from 2nd line
			String text = line;
			String[] parts = text.split("\t");
			String item = parts[0].replace("[name:", "").replace("]", "");
			int itemId = Integer.parseInt(parts[1]);
			dictonaryItems.put(item, itemId);
			dictonaryItemsString.put(parts[1], item);
		}

	}

}

private static Set<String> getTargetsList(File file) throws IOException {
	Set<String> elementList = new LinkedHashSet<>();
	if (file.isFile()) {
		BufferedReader br = new BufferedReader(new FileReader(file.toString()));
		String line;
		while ((line = br.readLine()) != null) {
			String text = line;
			String[] parts = text.split("#");
			if (parts.length == 2 && !parts[0].isBlank() && !parts[0].isEmpty() && parts[0] != null) {
				elementList.add(parts[0]);
			}
		}
	}
	return elementList;
}

private List<String> getTestCases(String splitFolder) {
	List<String> ret = new ArrayList<>();

	File dir = new File(splitFolder);
	File[] directoryListing = dir.listFiles();

	for (File file : directoryListing) {
		if (file.getName().startsWith("dataset_test_fold_")) {
			try {
				FileInputStream in = new FileInputStream(file.getAbsolutePath());
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String line;
				while ((line = br.readLine()) != null) {
					String text = line;
					String[] parts = text.split("\t");
					String targetId = parts[0];
					String itemId = parts[1];
					String target = MemoRecRecommendations.dictonaryTargetsString.get(targetId);
					String item = MemoRecRecommendations.dictonaryItemsString.get(itemId);
					ret.add(target + "#" + item);
				}
				br.close();

			} catch (

			Exception e) {
				// Ignore
			}

		}
	}

	return ret;

}
}
