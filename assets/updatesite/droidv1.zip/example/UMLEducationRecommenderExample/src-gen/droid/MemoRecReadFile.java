package droid;
	
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import filesExt.memorec.LevenshteinDistance;
import filesExt.memorec.LexicographicChanges;
import filesExt.memorec.Printer;
import filesExt.memorec.Sorter;
import filesExt.ranksys.ini.Element;
import filesExt.ranksys.ini.ReferenceElement;
	
public class MemoRecReadFile {
	private static Element target;
	private static List<ReferenceElement> items;
	private static String URI;

	// Writers
	public static FileWriter writerPostPreprocesingMatrix;
	public static FileWriter writerPostPreprocesingMatrixIdCoded;
	public static FileWriter writerPostPreprocesingEncoding;
	public static FileWriter writerOriginal;
	public static FileWriter writerOriginal2;
	FileWriter writer;

	// Maps
	static HashMap<Set<Object>, String> itemData = new HashMap<Set<Object>, String>();
	public static HashMap<Integer, Set<Object>> targetData = new HashMap<Integer, Set<Object>>();
	public static HashMap<Set<Object>, Integer> targetDataSer = new HashMap<Set<Object>, Integer>();
	static HashSet<String> targetDataOriginalUnique = new HashSet<String>();
	static HashMap<Set<Object>, Integer> itemDataSer = new HashMap<Set<Object>, Integer>();
	static HashSet<String> itemDataOriginalUnique = new HashSet<String>();
	static HashMap<Integer, String> itemDataTypeSer = new HashMap<Integer, String>();
	static HashMap<Integer, Set<Object>> itemSCR = new HashMap<Integer, Set<Object>>();
	static HashMap<Integer, Set<Object>> itemDataLD = new HashMap<Integer, Set<Object>>();
	static HashMap<Integer, Set<Object>> itemDataItemPerTarget = new HashMap<Integer, Set<Object>>();
	public static HashMap<Integer, Map<String, String>> dictonaryItemsLD = new HashMap<Integer, Map<String, String>>();
	public static HashMap<Integer, Map<String, String>> dictonaryItemsLDSorted = new HashMap<Integer, Map<String, String>>();
	public static HashMap<String, String> dictonaryItemsFinal = new HashMap<String, String>();

	//
	static int countItems = 0;
	static int countFiles = 0;
	static int countTarget = 0;
	public static String keyValue;
	private HashMap<Integer, Integer> usersItemDistributionAll = new HashMap<Integer, Integer>();
	private List<Integer> usersListAll = new ArrayList<>();
					
	String outputFilesFolder = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles";

public MemoRecReadFile(Element target, List<ReferenceElement> items, String URI) {
	MemoRecReadFile.target = target;
	MemoRecReadFile.items = items;
	MemoRecReadFile.URI = URI;
}

public void readFiles(Resource resource) throws IOException {
	TreeIterator<EObject> tree = resource.getAllContents();
	while (tree.hasNext()) {
		try {
			EObject obj = tree.next();
			readAttributeValues(obj);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}	

public void readAttributeValues(EObject obj) throws IOException {
	HashMap<String, String> mapUser = new HashMap<String, String>();
	HashMap<String, String> mapItems = new HashMap<String, String>();
	Set<Object> serialization = new TreeSet<Object>();

	if (obj.eClass().equals(target.getClass_e())) {
	if (!target.serialize(obj).isEmpty()) {
		mapUser = target.serialize(obj);
		for (Map.Entry<String, String> entryTarget : mapUser.entrySet()) {
			String valuePairTarget = entryTarget.getKey().trim() + ":" + entryTarget.getValue().trim();
			serialization.add(valuePairTarget.trim());
			targetData.put(countTarget, serialization);
			for (ReferenceElement item : items) {
				List<EObject> refList = item.getReferenceObject(obj);
				for (Object refListElement : refList) {
					mapItems = item.serialize((EObject) refListElement);
					String type = item.serialize2((EObject) refListElement);
					for (Map.Entry<String, String> entry : mapItems.entrySet()) {
						writerOriginal.write(entryTarget.getValue() + "#" + entry.getValue() + "\n");
						writerOriginal2.write(countTarget + "#" + entry.getValue() + "\n");
						Set<Object> itemSerialization = new TreeSet<Object>();
						String valuePair = entry.getKey().trim() + ":" + entry.getValue().trim();
						keyValue = entry.getKey();
						itemSerialization.add(valuePair.trim());
						itemData.put(itemSerialization, type.trim());
					}
				}
			}
		}
		countTarget = countTarget + 1;

		}
	}

}

public void preProcessingInitial(String outputFolderMemorecCoded, int ld, int ratTarget, boolean scr)
		throws IOException {
	String text = String.valueOf(ld) + String.valueOf(ratTarget) + Boolean.toString(scr);
	// Target are serialized all individually no cleanning by duplicates
	File folder = new File(outputFolderMemorecCoded + "/" + text + "/");
	if (!folder.exists()) {
		folder.mkdir();
	}
	String pathCoded = folder.toString();

	targetData = Sorter.sort(targetData);
	Printer.print(targetData, "valuesTarget", pathCoded);
	itemData = Sorter.sort4(itemData);
	
	Integer j = 0; // for the id's of item HashMap
	for (Entry<Set<Object>, String> entry : itemData.entrySet()) {
		Set<Object> key = entry.getKey();
		itemDataSer.put(key, j);
		itemDataTypeSer.put(j, entry.getValue());
		itemDataOriginalUnique.add(key.toString());
		j++;
	}

	Printer.print(itemDataSer, "valuesItems", pathCoded);
	Printer.print(itemDataTypeSer, "valuesItemsTypes", pathCoded);

	if (scr == true) {
		itemSCR = LexicographicChanges.specialCharactersRemoval(itemDataSer, writer);
		Printer.print(itemSCR, "p1-dataCleanedItemValues", pathCoded);

		System.out.println("  Levenshtein distance merging " + ld + "...");
		itemDataLD = LevenshteinDistance.merging(itemSCR, ld, writer, keyValue);
		Printer.print(itemDataLD, "p2-LDItemValues", pathCoded);

	} else {
		System.out.println("  Levenshtein distance merging " + ld + "...");
		itemDataLD = LevenshteinDistance.unifyWordsNoCleaned(itemDataSer, ld, writer, keyValue);
		Printer.print(itemDataLD, "p2-LDItemValues", pathCoded);
	}

	// Generate final dictionaries for items per target
	for (Entry<Set<Object>, Integer> entry : itemDataSer.entrySet()) {
		String oldWord = entry.getKey().toString().replace("[" + keyValue + ":", "").replace("]", "");
		int idOriginal = entry.getValue();
		for (Entry<Integer, Set<Object>> entry2 : itemDataLD.entrySet()) {
			int idOriginal2 = entry2.getKey();
			if (idOriginal == idOriginal2) {
				NavigableMap<String, String> mapWords = new TreeMap<String, String>();
				String[] wordPart = entry2.getValue().toString().split(">");
				String newWord = wordPart[0].replace("[" + keyValue + ":", "");
				mapWords.put(oldWord, newWord);
				if (!dictonaryItemsLD.containsKey(idOriginal)) {
					dictonaryItemsLD.put(idOriginal, new HashMap<>());
				}
				dictonaryItemsLD.get(idOriginal).putAll(mapWords);
				dictonaryItemsFinal.put(oldWord, newWord);
			}
		}
	}

	dictonaryItemsLDSorted = Sorter.sortForId(dictonaryItemsLD);
}

public void preProcessingUnified(File file, int ld, int ratTarget, boolean scr, String text) throws IOException {
	try {
		FileInputStream in = new FileInputStream(file.getAbsolutePath());
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;

		int idTarget = 0;
		while ((line = br.readLine()) != null) {
			String[] parts = line.split("#");
			String partTarget = parts[0];
			idTarget = Integer.parseInt(partTarget);

			if (!usersListAll.contains(idTarget)) {
				usersListAll.add(idTarget);
				usersItemDistributionAll.put(idTarget, 1);
			} else {
				usersItemDistributionAll.put(idTarget, usersItemDistributionAll.get(idTarget) + 1);
			}
		}
		br.close();

	} catch (

	Exception e) {
		// Ignore
	}

	try {
		FileInputStream in = new FileInputStream(file.getAbsolutePath());
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;

		int idTarget = 0;
		int idItem = 0;

		while ((line = br.readLine()) != null) {
			String[] parts = line.split("#");
			idTarget = Integer.parseInt(parts[0]);
			String partItem = parts[1];

			for (Entry<Integer, Map<String, String>> entryItem : dictonaryItemsLDSorted.entrySet()) {
				if (entryItem.getValue().containsKey(partItem)) {
					idItem = entryItem.getKey();
				}
			}

			for (Entry<Integer, Integer> entry : usersItemDistributionAll.entrySet()) {
				if (entry.getKey().equals(idTarget) && entry.getValue() >= ratTarget) {
					writerPostPreprocesingMatrix.write(idTarget + "\t" + idItem + "\t" + 1.0 + "\n");
				}
			}

		}
		br.close();

	} catch (

	Exception e) {
		// Ignore
	}
	countFiles = countFiles + 1;
}

public void preProcessingIndividual(String outputFolderMemorec, File file, int ld, int ratTarget, boolean scr,
		String text) throws IOException {

	File folder = new File(outputFolderMemorec + "/" + text + "/");
	if (!folder.exists()) {
		folder.mkdir();
	}

	writerPostPreprocesingEncoding = new FileWriter(folder.toString() + "/" + file.getName());
	HashMap<String, Integer> usersItemDistributionLocal = new HashMap<String, Integer>();
	List<String> usersListLocal = new ArrayList<>();
	int count = 0;
	try {
		FileInputStream in = new FileInputStream(file.getAbsolutePath());
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;
		String target = "";

		while ((line = br.readLine()) != null) {
			String[] parts = line.split("#");
			target = parts[0];

			if (!usersItemDistributionLocal.containsKey(target)) {
				usersItemDistributionLocal.put(target, count);
			}

			if (!usersListLocal.contains(target)) {
				usersListLocal.add(target);
				usersItemDistributionLocal.put(target, 1);
			} else {
				usersItemDistributionLocal.put(target, usersItemDistributionLocal.get(target) + 1);
			}
		}
		br.close();
	} catch (
	Exception e) {
		// Ignore
	}
	try {
		FileInputStream in = new FileInputStream(file.getAbsolutePath());
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;

		String target = "";
		String item = "";
		while ((line = br.readLine()) != null) {
			String[] parts = line.split("#");
			target = parts[0];
			item = dictonaryItemsFinal.get(parts[1]);

			for (Entry<String, Integer> entry : usersItemDistributionLocal.entrySet()) {
				if (entry.getKey().equals(target) && entry.getValue() >= ratTarget) {
					writerPostPreprocesingEncoding.write(target + "#" + item + "\n");
				}
			}
		}
		br.close();

	} catch (

	Exception e) {
		// Ignore
	}

	writerPostPreprocesingEncoding.close();
	}			
}
