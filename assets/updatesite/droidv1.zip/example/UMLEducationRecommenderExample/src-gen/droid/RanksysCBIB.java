package droid;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.ArrayList;

import filesExt.ranksys.cb.ItemProfiler;
import filesExt.ranksys.cb.CBIB;
import filesExt.ranksys.rec.RecommenderIF;

public class RanksysCBIB {
public static void execute(String[] codeCase) throws ClassNotFoundException, IllegalAccessException, InstantiationException,
			InvocationTargetException, NoSuchMethodException, IOException {
String project = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample";	
String[] datasets = new String[] {project}; 
String repository = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/instances";
						 	      
String nFolds = "10";
int maxRec = 5;
int[] cutoffs = {5,10};
String relevanceThreholds = "0.5";
String errorStrategy = "NOT_CONSIDER_NAN";

List<String> metricList = new ArrayList<String>();
metricList.add("Precision");metricList.add("Recall");metricList.add("F1");metricList.add("NDCG");metricList.add("ISC");metricList.add("USC");metricList.add("MAP");

String metrics = null;
List<String> metricsUSC_ISC = new ArrayList<String>();
int count = metricList.size();
for (String m : metricList) {
if (m.equals("Precision") || m.equals("Recall") || m.equals("NDCG") || m.equals("MAP")) {
if (metrics == null) {
if (count > 1) {
metrics = "net.recommenders.rival.evaluation.metric.ranking." + m + "," ;}
count = count - 1;} else {if (count > 1) {
metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m + ",");
} else {
metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m);}}
count = count - 1;}}
for (String m : metricList) {
if (m.equals("ISC")) {
metricsUSC_ISC.add("ItemSpaceCoverage");}
if (m.equals("USC")) {
metricsUSC_ISC.add("targetSpaceCoverage");}}

String featureFile = project + "/outputFiles/dataPostProcessing/ranksys/"+codeCase[0]+"_dataset_item_features.dat";

ItemProfiler ip = null;
if (new File(featureFile).exists() && new File(featureFile).isFile()) {
ip = ItemProfiler.read(featureFile);
}

List<RecommenderIF> recs = new ArrayList<>(); 

recs.add(new CBIB(ip, 5));recs.add(new CBIB(ip, 10));recs.add(new CBIB(ip, 15));
						;	
			Ranksys.recommendationCB(recs, ip, repository, datasets, codeCase[0], nFolds, maxRec);
			try {
			Ranksys.evaluation(datasets, nFolds, relevanceThreholds, errorStrategy, cutoffs, metrics, metricsUSC_ISC);
			} catch (ClassNotFoundException | IllegalAccessException | InstantiationException | InvocationTargetException
				| NoSuchMethodException | IOException e) {
					e.printStackTrace();}}}
