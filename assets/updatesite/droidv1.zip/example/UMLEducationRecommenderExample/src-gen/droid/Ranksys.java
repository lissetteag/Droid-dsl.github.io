package droid;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeSet;

import org.ranksys.formats.parsing.Parsers;
import org.ranksys.formats.preference.SimpleRatingPreferencesReader;

import es.uam.eps.ir.ranksys.core.preference.ConcatPreferenceData;
import es.uam.eps.ir.ranksys.core.preference.PreferenceData;
import es.uam.eps.ir.ranksys.core.preference.SimplePreferenceData;
import es.uam.eps.ir.ranksys.fast.index.FastItemIndex;
import es.uam.eps.ir.ranksys.fast.index.FastUserIndex;
import es.uam.eps.ir.ranksys.fast.index.SimpleFastItemIndex;
import es.uam.eps.ir.ranksys.fast.index.SimpleFastUserIndex;
import es.uam.eps.ir.ranksys.fast.preference.FastPreferenceData;
import es.uam.eps.ir.ranksys.fast.preference.SimpleFastPreferenceData;
import filesExt.ranksys.cb.ItemProfiler;
import filesExt.ranksys.eval.ItemSpaceCoverage;
import filesExt.ranksys.eval.UserSpaceCoverage;
import filesExt.ranksys.rec.RecommenderIF;
import net.recommenders.rival.core.DataModel;
import net.recommenders.rival.core.SimpleParser;
import net.recommenders.rival.evaluation.metric.EvaluationMetric;
import net.recommenders.rival.evaluation.metric.MultipleEvaluationMetricRunner;
import net.recommenders.rival.evaluation.metric.ranking.AbstractRankingMetric;

public class Ranksys {					
	public static void recommendation(RecommenderIF[] recList, String repository, String[] datasets, String codeCase,
				String nFolds, int maxRec) throws IOException {
		String[] args;
		for (String dataset : datasets) {
			args = new String[] { "rec_all", dataset + "/outputFiles/", dataset + "/outputFiles/droidDSL/ranksys/splits/", repository + "/outputFiles/droidDSL/ranksys/recs/" };
			String option = args[0];
			System.out.println("Running recommenders: " + option + ": " + dataset + " recs...");

			System.out.println("rec_all feature_folder split_folder rec_folder");
			System.out.println(Arrays.deepToString(args));

			args = new String[] { "rec", dataset + "/outputFiles/dataPostProcessing/ranksys/"+codeCase+"_dataset_item_features.dat", dataset + "/outputFiles/droidDSL/ranksys/splits/dataset_", dataset + "/outputFiles/droidDSL/ranksys/recs/dataset_"};

			System.out.println("rec feature_file input_folder output_folder");
			System.out.println(Arrays.toString(args));

			boolean doErr = false;
			String featureFile = args[1];
			String inputFolder = args[2];
			String outputFolder = args[3];

			ItemProfiler ip = null;
			if (new File(featureFile).exists() && new File(featureFile).isFile()) {
				ip = ItemProfiler.read(featureFile);
			}

			String featureFileShort = (ip == null ? "nofeature" : new File(featureFile).getName());
			int index = featureFileShort.lastIndexOf("_");
			if (index > 0) {
				featureFileShort = featureFileShort.substring(index + 1).replace(".dat", "");
			}

			int folds = Integer.parseInt(nFolds);

			for (int fold = 0; fold < folds; fold++) {
			String trainFile = inputFolder + "train_fold_" + fold + "_global.dat";
			String testFile = inputFolder + "test_fold_" + fold + "_global.dat";
			DataModel<Long, Long> trainModel = null;
			DataModel<Long, Long> testModel = null;
			PreferenceData<Long, Long> trainPref = SimplePreferenceData.load(SimpleRatingPreferencesReader.get().read(trainFile, Parsers.lp, Parsers.lp));
			PreferenceData<Long, Long> testPref = SimplePreferenceData.load(SimpleRatingPreferencesReader.get().read(testFile, Parsers.lp, Parsers.lp));
			PreferenceData<Long, Long> totalPref = new ConcatPreferenceData<>(trainPref, testPref);
			FastUserIndex<Long> targetIndex = SimpleFastUserIndex.load(totalPref.getAllUsers());
			FastItemIndex<Long> itemIndex = SimpleFastItemIndex.load(totalPref.getAllItems());

			FastPreferenceData<Long, Long> trainData = SimpleFastPreferenceData.load(
					SimpleRatingPreferencesReader.get().read(trainFile, Parsers.lp, Parsers.lp), targetIndex,itemIndex);
			FastPreferenceData<Long, Long> testData = SimpleFastPreferenceData.load(
					SimpleRatingPreferencesReader.get().read(testFile, Parsers.lp, Parsers.lp), targetIndex,itemIndex);

			if (recList != null) {
				for (RecommenderIF rec : recList) {
					File theDir = new File(outputFolder.replace("dataset_", "recommenders") + "\\" + rec);
					if (!theDir.exists()){
						theDir.mkdirs();
						}
					String outputFolder2 = theDir.getAbsolutePath().replace("\\", "/") + "/";
					
					tryAndWriteRecommender(outputFolder2, fold, featureFileShort, rec, trainModel, testModel,
					trainData, testData, maxRec, doErr);
											
					tryAndWriteRecommender(outputFolder, fold, featureFileShort, rec, trainModel, testModel,
					trainData, testData, maxRec, doErr);
				}
			}
		}
	}
	System.out.println("---------------------------------------------");					
}

	public static void recommendationCB(List<RecommenderIF> recList, ItemProfiler ip, String repository, String[] datasets, String codeCase,
				String nFolds, int maxRec) throws IOException {
		String[] args;
		for (String dataset : datasets) {
			args = new String[] { "rec_all", dataset + "/outputFiles/", dataset + "/outputFiles/droidDSL/ranksys/splits/", repository + "/outputFiles/droidDSL/ranksys/recs/" };
			String option = args[0];
			System.out.println("Running recommenders: " + option + ": " + dataset + " recs...");

			System.out.println("rec_all feature_folder split_folder rec_folder");
			System.out.println(Arrays.deepToString(args));

			args = new String[] { "rec", dataset + "/outputFiles/dataPostProcessing/ranksys/"+codeCase+"_dataset_item_features.dat", dataset + "/outputFiles/droidDSL/ranksys/splits/dataset_", dataset + "/outputFiles/droidDSL/ranksys/recs/dataset_"};

			System.out.println("rec feature_file input_folder output_folder");
			System.out.println(Arrays.toString(args));

			boolean doErr = false;
			String featureFile = args[1];
			String inputFolder = args[2];
			String outputFolder = args[3];

			String featureFileShort = (ip == null ? "nofeature" : new File(featureFile).getName());
			int index = featureFileShort.lastIndexOf("_");
			if (index > 0) {
				featureFileShort = featureFileShort.substring(index + 1).replace(".dat", "");
			}

			int folds = Integer.parseInt(nFolds);

			for (int fold = 0; fold < folds; fold++) {
			String trainFile = inputFolder + "train_fold_" + fold + "_global.dat";
			String testFile = inputFolder + "test_fold_" + fold + "_global.dat";
			DataModel<Long, Long> trainModel = null;
			DataModel<Long, Long> testModel = null;
			PreferenceData<Long, Long> trainPref = SimplePreferenceData.load(SimpleRatingPreferencesReader.get().read(trainFile, Parsers.lp, Parsers.lp));
			PreferenceData<Long, Long> testPref = SimplePreferenceData.load(SimpleRatingPreferencesReader.get().read(testFile, Parsers.lp, Parsers.lp));
			PreferenceData<Long, Long> totalPref = new ConcatPreferenceData<>(trainPref, testPref);
			FastUserIndex<Long> targetIndex = SimpleFastUserIndex.load(totalPref.getAllUsers());
			FastItemIndex<Long> itemIndex = SimpleFastItemIndex.load(totalPref.getAllItems());

			FastPreferenceData<Long, Long> trainData = SimpleFastPreferenceData.load(
					SimpleRatingPreferencesReader.get().read(trainFile, Parsers.lp, Parsers.lp), targetIndex,itemIndex);
			FastPreferenceData<Long, Long> testData = SimpleFastPreferenceData.load(
					SimpleRatingPreferencesReader.get().read(testFile, Parsers.lp, Parsers.lp), targetIndex,itemIndex);

		if (ip != null) {
				for (RecommenderIF rec : recList) {
					
					File theDir = new File(outputFolder.replace("dataset_", "recommenders") + "\\" + rec);
					if (!theDir.exists()){
						theDir.mkdirs();
						}
					String outputFolder2 = theDir.getAbsolutePath().replace("\\", "/") + "/";
					tryAndWriteRecommender(outputFolder2, fold, featureFileShort, rec, trainModel, testModel,
					trainData, testData, maxRec, doErr);
												
					tryAndWriteRecommender(outputFolder, fold, featureFileShort, rec, trainModel, testModel,
					trainData, testData, maxRec, doErr);
				}
			}
		}
	}
	System.out.println("---------------------------------------------");					
}
			
	public static void evaluation(String[] datasets, String nFolds, String relevanceThreholds, String errorStrategy,
				int[] cutoffs, String metrics, List<String> metricsUSC_ISC) throws IOException, ClassNotFoundException,
			IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException {
		String[] args;
		for (String dataset : datasets) {
			args = new String[] { "eval",  dataset + "/outputFiles/droidDSL/ranksys/splits/dataset_", dataset + "/outputFiles/droidDSL/ranksys/recs/", dataset + "/outputFiles/droidDSL/ranksys/evals/" };
			System.out.println("Running evaluations: " + dataset + " evals...");
			
			System.out.println("eval splits_folder rec_folder eval_folder");
			System.out.println(Arrays.toString(args));

			String dataFolder = args[1];
			String recFolder = args[2]; 
			String evalFolder = args[3]; 
			String outputFile = null;

			int folds = Integer.parseInt(nFolds);
			for (int fold = 0; fold < folds; fold++) {
				String trainFile = dataFolder + "train_fold_" + fold + "_global.dat";
				DataModel<Long, Long> trainModel = new SimpleParser().parseData(new File(trainFile));
				String testFile = dataFolder + "test_fold_" + fold + "_global.dat";
				DataModel<Long, Long> testModel = new SimpleParser().parseData(new File(testFile));

				final String prefix = "dataset_rec_fold_" + fold + "__";

				for (File recFile : new File(recFolder).listFiles(new FilenameFilter() {
					@Override
					public boolean accept(File dir, String name) {
						return name.startsWith(prefix);
					}
				})) {
					String cutoffs2= Arrays.toString(cutoffs).replace("[", "").replace("]", "").replaceAll(" ", "");
					outputFile = evalFolder + "eval_" + recFile.getName();
					Properties evalProps = new Properties();
					evalProps.setProperty(MultipleEvaluationMetricRunner.METRICS, metrics);
					evalProps.setProperty(MultipleEvaluationMetricRunner.RELEVANCE_THRESHOLD, relevanceThreholds); 
					evalProps.setProperty(MultipleEvaluationMetricRunner.RANKING_CUTOFFS, cutoffs2);
					evalProps.setProperty(MultipleEvaluationMetricRunner.ERROR_STRATEGY, errorStrategy);

					DataModel<Long, Long> predictions = new SimpleParser().parseData(recFile);

					Map<String, Map<String, Double>> mapResults = evaluateStrategy(evalProps, testModel, predictions,
							trainModel, cutoffs, metricsUSC_ISC);
					PrintStream out = new PrintStream(new File(outputFile));
					for (String metric : new TreeSet<>(mapResults.keySet())) {
						out.println(metric + "\t" + mapResults.get(metric).get("all"));
					}
					out.close();
				}
			}
		}
		System.out.println("---------------------------------------------");
	}

	public static void summaryEvaluation(String[] datasets) throws IOException {
		String[] args;
		for (String dataset : datasets) {
			args = new String[] { "summary_eval", dataset + "/outputFiles/droidDSL/ranksys/evals/", dataset +"/outputFiles/droidREST/result/results.dat" };
			System.out.println("summary_eval eval_folder summary_file");
			System.out.println(Arrays.toString(args));

			String inFolder = args[1];
			String outFile = args[2];

			PrintStream out = new PrintStream(new FileOutputStream(outFile, true));
			for (File f : new File(inFolder).listFiles()) {

				String method = f.getName().substring(f.getName().indexOf("__") + 2);
				dataset = f.getName().replace("eval_", "");
				dataset = dataset.substring(0, dataset.indexOf("_rec"));

				BufferedReader in = new BufferedReader(new FileReader(f));
				String line = null;
				while ((line = in.readLine()) != null) {

					String tokens[] = line.split("\t");
					String metric = tokens[0];
					String value = tokens[1].replace(",", ".");
					out.println(method + "," + metric + "," + value);
				}
				in.close();
			}
			out.close();
		}
		System.out.println("---------------------------------------------");
	}

	private static Map<String, Map<String, Double>> evaluateStrategy(final Properties properties,
			final DataModel<Long, Long> test, final DataModel<Long, Long> modelToEvaluate,
			final DataModel<Long, Long> training, final int[] cutoffs, List<String> metricsUSC_ISC) throws ClassNotFoundException,
			IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException {
		Map<String, Map<String, Double>> mapMetricResults = new HashMap<>();
		EvaluationMetric<Long>[] metrics0 = MultipleEvaluationMetricRunner.instantiateEvaluationMetrics(properties,
				modelToEvaluate, test);

		
		int extraSize = metricsUSC_ISC.size();
		@SuppressWarnings("unchecked")
		EvaluationMetric<Long>[] metrics2 = new EvaluationMetric[metrics0.length + extraSize];
		for (int i =0 ; i< metricsUSC_ISC.size(); i++) {
					if (metricsUSC_ISC.get(i).equals("targetSpaceCoverage")) {
						metrics2[i] = new UserSpaceCoverage<>(modelToEvaluate, test, cutoffs);
					}
					if (metricsUSC_ISC.get(i).equals("ItemSpaceCoverage")) {
						metrics2[i] = new ItemSpaceCoverage<>(modelToEvaluate, test, training, cutoffs);
					}
				}		

		
		for (int i = 0; i < metrics0.length; i++) {
			metrics2[i + extraSize] = metrics0[i];
		}
		for (EvaluationMetric<Long> metric : metrics2) {
			metric.compute();
			Double all = metric.getValue();
			Map<String, Double> results = new HashMap<>();
			mapMetricResults.put(metric.toString() + "_@0", results);

			results.put("all", all);
			Map<Long, Double> perUser = metric.getValuePerUser();
			for (Entry<Long, Double> e : perUser.entrySet()) {
				Long u = e.getKey();
				results.put(u.toString(), e.getValue());
			}
			if(metric instanceof AbstractRankingMetric)

			{

				AbstractRankingMetric<Long, Long> rankingMetric = (AbstractRankingMetric<Long, Long>) metric;
				for (int n : rankingMetric.getCutoffs()) {
					all = rankingMetric.getValueAt(n);
					results = new HashMap<>();
					mapMetricResults.put(metric.toString() + "_@" + n, results);
					results.put("all", all);
					perUser = rankingMetric.getValuePerUser();
					for (Long u : perUser.keySet()) {
						results.put(u.toString(), rankingMetric.getValueAt(u, n));
					}
				}
			}
			}return mapMetricResults;

			}

	public static void tryAndWriteRecommender(String outputFolder, int fold, String featureFileShort, RecommenderIF rec,
			DataModel<Long, Long> trainModel, DataModel<Long, Long> testModel, FastPreferenceData<Long, Long> trainData,
			FastPreferenceData<Long, Long> testData, int maxRec, boolean doErr) throws FileNotFoundException {
		tryAndWriteRecommender(outputFolder, "fold_" + fold, featureFileShort, rec, trainModel, testModel, trainData,
				testData, maxRec, doErr);
	}

	public static void tryAndWriteRecommender(String outputFolder, String prefix, String featureFileShort,
			RecommenderIF rec, DataModel<Long, Long> trainModel, DataModel<Long, Long> testModel,
			FastPreferenceData<Long, Long> trainData, FastPreferenceData<Long, Long> testData, int maxRec,
			boolean doErr) throws FileNotFoundException {
		String outputFile = outputFolder + "rec_" + prefix + "__" + featureFileShort + "_" + rec.toString();
		String outputFileErr = outputFolder + "recerr_" + prefix + "__" + featureFileShort + "_" + rec.toString();
		if (!new File(outputFile).exists()) {
			PrintStream out = new PrintStream(outputFile);
			PrintStream outErr = null;
			if (doErr) {
				outErr = new PrintStream(outputFileErr);
			}
			
			if (trainModel != null) {
				rec.train(trainModel);
			}
			if (trainData != null) {
				rec.train(trainData);
			}
			boolean evaluated = false;
			if (testModel != null) {
				for (Long u : testModel.getUsers()) {
					int rank = 1;
					for (Long i : rec.recommend(u, maxRec)) {
						out.println(u + "\t" + i + "\t" + 1.0 / rank);
						rank++;
					}
					if (outErr != null) {
						for (Long i : testModel.getUserItemPreferences().get(u).keySet()) {
							double s = rec.predict(u, i);
							outErr.println(u + "\t" + i + "\t" + s);
						}
					}
				}
				evaluated = true;
			}
			if (testData != null && !evaluated) {
				final PrintStream outErrFinal = outErr;
				testData.getUsersWithPreferences().forEach(u -> {
					int rank = 1;
					for (Long i : rec.recommend(u, maxRec)) {
						out.println(u + "\t" + i + "\t" + 1.0 / rank);
						rank++;
					}
					if (outErrFinal != null) {
						testData.getUserPreferences(u).forEach(p -> {
							Long i = p.v1();
							double s = rec.predict(u, i);
							outErrFinal.println(u + "\t" + i + "\t" + s);
						});
					}
				});
				evaluated = true;
			}
			out.close();
			if (outErr != null) {
				outErr.close();
			}
		} else {
			System.out.println("Ignoring " + outputFile);
		}
}
}       
