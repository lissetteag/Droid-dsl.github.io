package droid;          
import java.io.File;
import java.io.FileWriter;
import org.apache.commons.io.FileUtils;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.common.util.URI;
import org.eclipse.uml2.uml.UMLPackage;
public class EngineConfiguration {
	public static String URIEditor = null;
	static String codeCase;
	   public static void main(String[] args) throws Exception {
			String project = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample";	
			String outputFilesFolder = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample/outputFiles";
			String codeCase = args[0];
			
			URIEditor = UMLPackage.eNS_URI.toString();
			
			String[] datasets = new String[] {project};
			String splitType = "CrossValidation";
			 	      
			 	      String nFolds = "10";
			 	      String perUser = "true"; 
			 	      String perItem = "false"; 
			 	      String percentageTraining = "0.0"; 
			 	      int maxRec = 5;

	   	   List<String> methodsList = new ArrayList<String>();
	   	   methodsList.add("ItemPop");
	   	   methodsList.add("CosineCB");
	   	   methodsList.add("CACF");
	   	   methodsList.add("IBCF");
	   	   methodsList.add("UBCF");
	   	   methodsList.add("CBIB");
	   	   methodsList.add("CBUB");
	
		   	   
		   	   List<String> metricList = new ArrayList<String>();
		   	   metricList.add("Precision");metricList.add("Recall");metricList.add("F1");metricList.add("NDCG");metricList.add("ISC");metricList.add("USC");metricList.add("MAP");
	FileWriter writer2 = new FileWriter(outputFilesFolder + "/droidREST/general/editorMetrics.txt");
	for(String str: metricList) {
		writer2.write(str + System.lineSeparator());}
		writer2.close();		
	String metrics = null;
	List<String> metricsUSC_ISC = new ArrayList<String>();
	int count = metricList.size();
	for (String m : metricList) {
		if (m.equals("Precision") || m.equals("Recall") || m.equals("NDCG") || m.equals("MAP")) {
			if (metrics == null) {
				if (count > 1) {
					metrics = "net.recommenders.rival.evaluation.metric.ranking." + m + "," ;}
				count = count - 1;
			} else {if (count > 1) {
					metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m + ",");
				} else {
					metrics = metrics.concat("net.recommenders.rival.evaluation.metric.ranking." + m);
				}
			}
			count = count - 1;}}
	for (String m : metricList) {
		if (m.equals("ISC")) {
			metricsUSC_ISC.add("ItemSpaceCoverage");}
		if (m.equals("USC")) {metricsUSC_ISC.add("targetSpaceCoverage");}}
	String relevanceThreholds = "0.5";
	FileWriter writer = new FileWriter(outputFilesFolder + "/droidREST/general/editorGeneral.txt");
	writer.write("maxRecommendation," + maxRec + System.lineSeparator());		
	writer.write("URIEditor," + URIEditor + System.lineSeparator());
	writer.write("relevanceThreholds," + relevanceThreholds + System.lineSeparator());
	writer.write("nFolds," + nFolds + System.lineSeparator());
	writer.write("language,uml");
	
	writer.close();
						
	String splitsFolder = outputFilesFolder + "/droidDSL/ranksys/splits";
	String RecsFolder = outputFilesFolder + "/droidDSL/ranksys/recs";
	String EvalsFolder = outputFilesFolder + "/droidDSL/ranksys/evals";
	String resultFolder = outputFilesFolder + "/droidREST/result";
	
	  FileUtils.cleanDirectory(new File(splitsFolder)); 
	  FileUtils.cleanDirectory(new File(RecsFolder)); 
	  FileUtils.cleanDirectory(new File(EvalsFolder)); 
	  FileUtils.cleanDirectory(new File(resultFolder));
	
	 Data data = new Data(splitType, nFolds, perUser, perItem, percentageTraining, codeCase);
	 data.split(datasets, null, null, "ranksys");
	 }
	
		public static URI createURI(String uriString){
			if (uriString.startsWith("platform:/resource/")) return URI.createPlatformResourceURI(uriString.replaceFirst("^platform:/resource/", ""), true);
				if (uriString.startsWith("platform:/plugin/"))   return URI.createPlatformPluginURI(uriString.replaceFirst("^platform:/plugin/", ""), true);
				if (uriString.startsWith("http:/"))              return URI.createURI(uriString);       
				return URI.createFileURI(new File(uriString).getAbsolutePath());
		}}
		
