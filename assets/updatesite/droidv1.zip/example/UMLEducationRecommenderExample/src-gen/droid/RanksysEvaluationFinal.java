package droid;
		
import java.io.IOException;
		
public class RanksysEvaluationFinal {
public static void execute() throws IOException {
String project = "C:/Users/Usuario/eclipse-workspace-Example/UMLEducationRecommenderExample";	
String[] datasets = new String[] {project}; 
								 	      
Ranksys.summaryEvaluation(datasets);
	}
}  
