package droid;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import net.recommenders.rival.core.DataModel;
import net.recommenders.rival.core.SimpleParser;
import net.recommenders.rival.split.splitter.SplitterRunner;

public class Data {
	private String splitType;
	private String nFolds;
	private String perUser;
	private String perItem;
	private String percentageTraining;
	private String codeCase;
	
	public Data(String splitType, String nFolds, String perUser, String perItem, String percentageTraining, String codeCase) {
	this.splitType = splitType;
	this.nFolds = nFolds;
	this.perUser = perUser;
	this.perItem = perItem;
	this.percentageTraining = percentageTraining;
	this.codeCase = codeCase;
	}

	public void split(String[] datasets, String outputFolderUnifiedMatrix, String outputFolderDroidDSL, String library) throws IOException {
		String[] args = null;
		String inputFile = "";
		String outputFolder = "";
		
		if (splitType.equals("CrossValidation")) {
			System.out.println("Split type: " + splitType);
			for (String dataset : datasets) {
				if(library.equals("ranksys")){
						args = new String[] { "split",
						dataset + "/outputFiles/dataPostProcessing/" +library +"/" + codeCase + "_dataset_ratings.dat",
						dataset + "/outputFiles/droidDSL/" + library + "/splits/dataset_"};
						inputFile = args[1];
						outputFolder = args[2];
						System.out.println("Running split: " + dataset + "...");
						System.out.println("split input_file output_folder");
						System.out.println(Arrays.deepToString(args));
					}
				else if(library.equals("memorec")){
						inputFile = dataset + "/outputFiles/droidREST/coded/"+library+"/"+codeCase+"/"+"dataset_ratings.dat";
						outputFolder = outputFolderDroidDSL + "splits/dataset_";
					}

				Properties splitProps = new Properties();
				System.out.println("Setting splitting properties");
				splitProps.setProperty(SplitterRunner.DATASET_SPLITTER, splitType);
				splitProps.setProperty(SplitterRunner.SPLIT_CV_NFOLDS, nFolds);
				splitProps.setProperty(SplitterRunner.SPLIT_PERUSER, perUser);
				splitProps.setProperty(SplitterRunner.SPLIT_PERITEMS, perItem);
				splitProps.setProperty(SplitterRunner.SPLIT_OUTPUT_FOLDER, outputFolder);
				splitProps.setProperty(SplitterRunner.SPLIT_OUTPUT_OVERWRITE, "true");
				splitProps.setProperty(SplitterRunner.SPLIT_TRAINING_PREFIX, "train_fold_");
				splitProps.setProperty(SplitterRunner.SPLIT_TRAINING_SUFFIX, "_global.dat");
				splitProps.setProperty(SplitterRunner.SPLIT_TEST_PREFIX, "test_fold_");
				splitProps.setProperty(SplitterRunner.SPLIT_TEST_SUFFIX, "_global.dat");
				splitProps.setProperty(SplitterRunner.SPLIT_SEED, "201804");

				DataModel<Long, Long> model = new SimpleParser().parseData(new File(inputFile));
				SplitterRunner.run(splitProps, model, false);
			}
				System.out.println("---------------------------------------------");
		} else if (splitType.equals("Random")) {
			System.out.println("Split type: " + splitType);
			for (String dataset : datasets) {
				if(library.equals("ranksys")){
						args = new String[] { "split",
						dataset + "/outputFiles/dataPostProcessing/" +library +"/" + codeCase + "_dataset_ratings.dat",
						dataset + "/outputFiles/droidDSL/" + library + "/splits/dataset_"
						};
					}
				else if(library.equals("memorec")){
						args = new String[] { "split",
						dataset + "/outputFiles/droidREST/coded/"+library+"/"+codeCase+"/"+"dataset_ratings.dat",
						dataset + "/outputFiles/droidDSL/"+library+"/splits/dataset_"
						};
					}

				System.out.println("Running split: " + dataset + "...");
				System.out.println("split input_file output_folder");
				System.out.println(Arrays.deepToString(args));

				Properties splitProps = new Properties();
				splitProps.setProperty(SplitterRunner.DATASET_SPLITTER, splitType);
				splitProps.setProperty(SplitterRunner.SPLIT_PERUSER, perUser);
				splitProps.setProperty(SplitterRunner.SPLIT_RANDOM_PERCENTAGE, percentageTraining);
				splitProps.setProperty(SplitterRunner.SPLIT_OUTPUT_FOLDER, outputFolder);
				splitProps.setProperty(SplitterRunner.SPLIT_OUTPUT_OVERWRITE, "true");
				splitProps.setProperty(SplitterRunner.SPLIT_TRAINING_PREFIX, "train_fold_");
				splitProps.setProperty(SplitterRunner.SPLIT_TRAINING_SUFFIX, "_global.dat");
				splitProps.setProperty(SplitterRunner.SPLIT_TEST_PREFIX, "test_fold_");
				splitProps.setProperty(SplitterRunner.SPLIT_TEST_SUFFIX, "_global.dat");
				splitProps.setProperty(SplitterRunner.SPLIT_SEED, "201804");

				DataModel<Long, Long> model = new SimpleParser().parseData(new File(inputFile));
				SplitterRunner.run(splitProps, model, false);

				System.out.println("---------------------------------------------");
			}
		}
	}
}
